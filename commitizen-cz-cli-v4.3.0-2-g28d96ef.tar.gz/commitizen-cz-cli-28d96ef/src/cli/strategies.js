import git from './strategies/git';
import gitCz from './strategies/git-cz';

export {
  git,
  gitCz
};
