var commitizen = require('./commitizen');
module.exports = commitizen;
